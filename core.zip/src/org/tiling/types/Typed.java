package org.tiling.types;

public interface Typed {
	public Type getType();
}